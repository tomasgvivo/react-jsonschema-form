module.exports = {
  schema: {
    title: "A single-field form",
    type: "string",
  },
  formData: "initial value",
  uiSchema: {},
};

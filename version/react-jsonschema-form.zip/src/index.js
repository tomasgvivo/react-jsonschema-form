import Form from "./components/Form";

export default Form;
